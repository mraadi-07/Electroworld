// Minimal, accessible brand interaction for "Electro World".
// - Gentle hover/focus lift
// - Keyboard activation (Enter/Space) triggers a small visual feedback
// - No heavy particle effects (keeps UI calm and minimal)

(function(){
  const brandEl = document.getElementById('brand');
  if (!brandEl) return;

  // keyboard activation: Enter / Space should act like click
  brandEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      brandClickFeedback();
    }
  });

  // pointer click feedback
  brandEl.addEventListener('click', (e) => {
    brandClickFeedback();
  });

  // simple visual feedback on activation (brief scale + glow)
  function brandClickFeedback() {
    brandEl.style.transition = 'transform 140ms ease, box-shadow 160ms ease';
    brandEl.style.transform = 'translateY(-4px) scale(1.02)';
    brandEl.style.boxShadow = '0 14px 40px rgba(12,22,34,0.08)';
    setTimeout(() => {
      brandEl.style.transform = '';
      brandEl.style.boxShadow = '';
    }, 220);
  }

  // optional: expose a small API if other scripts want to trigger brand feedback
  window.ELECTRO_BRAND = {
    pulse: brandClickFeedback
  };
})();