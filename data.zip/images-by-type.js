// images-by-type.js
// Lightweight helper that assigns an image URL to product DOM nodes and product objects
// based on their type (or category). Non-destructive: existing non-placeholder src is left as-is.
//
// Usage:
//  - Include this file before your main script.js (already done in index.html above).
//  - It exposes window.TypeImageUtils.
//  - On DOMContentLoaded it automatically calls applyTypeImagesToDOM() to update images present in the page.
//  - If you have a PRODUCTS array, call TypeImageUtils.applyTypeImagesToProducts(PRODUCTS) before renderProducts(...).

(function () {
  // Map of canonical type -> search keywords (tunable)
  const TYPE_IMAGE_MAP = {
    "Monitor": "monitor,screen,display",
    "Camera": "camera,photography,DSLR",
    "Mouse": "computer mouse,gaming mouse",
    "Webcam": "webcam,video camera",
    "Smartphone": "smartphone,phone,mobile",
    "Smartwatch": "smartwatch,wearable",
    "Router": "wifi router,network",
    "Speakers": "speakers,audio,stereo",
    "USB Cable": "usb cable,charging cable",
    "Memory Card": "memory card,sd card",
    "Charger": "charger,power adapter",
    "Tablet": "tablet device,ipad",
    "Laptop": "laptop,notebook",
    "Tripod": "tripod,camera tripod",
    "Printer": "printer,printing",
    "Headphones": "headphones,over ear",
    "Keyboard": "keyboard,mechanical keyboard",
    "Microphone": "microphone,studio microphone",
    "External HDD": "external hard drive,hdd,storage",
    "Power Bank": "power bank,portable charger",
    // fallback generic
    "default": "electronics,gadgets,tech"
  };

  // Get an image URL for a given type. Default to Unsplash query URLs.
  function getImageForType(type, width = 800, height = 560) {
    const key = (TYPE_IMAGE_MAP[type] || TYPE_IMAGE_MAP['default'] || type || 'electronics');
    // Unsplash Source is convenient for prototyping; images will differ on each load.
    const q = encodeURIComponent(key);
    return `https://source.unsplash.com/${width}x${height}/?${q}`;
  }

  function isPlaceholderSrc(src) {
    if (!src) return true;
    // treat via.placeholder, data:image empty or images generated with '?text=' as placeholders
    return src.includes('placeholder.com') || src.includes('?text=') || src.startsWith('data:') || src.trim() === '';
  }

  // Try to detect a type from element attributes: data-type, data-category, alt text content
  function detectTypeFromElement(el) {
    if (!el) return null;
    // check enclosing .best-item or .product-card for data-type/data-category
    const wrapper = el.closest('.best-item, .product-card, [data-type], [data-category]');
    if (wrapper) {
      if (wrapper.dataset.type) return wrapper.dataset.type;
      if (wrapper.dataset.category) return wrapper.dataset.category;
    }
    // fallback: check element alt text for keywords
    const alt = el.getAttribute('alt') || '';
    if (alt) {
      for (const t of Object.keys(TYPE_IMAGE_MAP)) {
        if (t === 'default') continue;
        if (alt.toLowerCase().includes(t.toLowerCase())) return t;
      }
    }
    return null;
  }

  // Apply images to existing DOM <img> elements for products (non-destructive)
  function applyTypeImagesToDOM(options = {}) {
    const imgs = Array.from(document.querySelectorAll('.best-item img, .product-card img, #product-grid img'));
    imgs.forEach(img => {
      try {
        // only replace when src looks like a placeholder or missing
        const src = img.getAttribute('src') || '';
        if (src && !isPlaceholderSrc(src) && !options.force) return;

        const detected = detectTypeFromElement(img);
        const newUrl = getImageForType(detected || 'default', options.width || 400, options.height || 260);
        img.src = newUrl;
        // set alt if missing
        if (!img.alt || img.alt.trim() === '') {
          img.alt = detected ? `Image of ${detected}` : 'Product image';
        }
      } catch (err) {
        // ignore single failures
        console.warn('TypeImageUtils: failed to set image for', img, err);
      }
    });
  }

  // If you keep products objects in memory, this helper will fill missing img props
  function applyTypeImagesToProducts(products = [], extractor) {
    if (!Array.isArray(products)) return;
    products.forEach(p => {
      if (!p) return;
      if (p.img && !isPlaceholderSrc(p.img)) return; // keep existing real images
      // extractor can return a type string for a product
      let type = null;
      if (typeof extractor === 'function') type = extractor(p);
      if (!type) type = p.type || p.category || p.item_type || null;
      // try to find type keyword in title
      if (!type && p.title) {
        for (const t of Object.keys(TYPE_IMAGE_MAP)) {
          if (t === 'default') continue;
          if (p.title.toLowerCase().includes(t.toLowerCase())) { type = t; break; }
        }
      }
      p.img = getImageForType(type || 'default');
    });
  }

  // Public API
  window.TypeImageUtils = {
    TYPE_IMAGE_MAP,
    getImageForType,
    applyTypeImagesToDOM,
    applyTypeImagesToProducts,
  };

  // Auto-run on DOMContentLoaded so existing product elements on the page are updated.
  document.addEventListener('DOMContentLoaded', () => {
    try { applyTypeImagesToDOM(); } catch (e) { /* fail silently */ }
  });
})();