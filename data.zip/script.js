// script.js
// Your existing listener + integration with TypeImageUtils so product images are filled by type.

(function () {
  // Ensure original wiring exists (example)
  function attachProductGridListeners() {
    document.querySelectorAll('.add-btn, .add-to-cart').forEach(b => {
      // avoid duplicate listeners
      if (b.dataset._wired === '1') return;
      b.dataset._wired = '1';
      b.addEventListener('click', (e) => {
        const id = e.currentTarget.dataset.id;
        // call existing addToCart if defined (your app should implement it)
        if (typeof window.addToCart === 'function') {
          window.addToCart(id, 1);
        } else {
          console.log('addToCart not defined. clicked id=', id);
        }
      });
    });
  }

  // If TypeImageUtils is available and you also keep a PRODUCTS array in memory,
  // you can prefill product objects before rendering by calling:
  // TypeImageUtils.applyTypeImagesToProducts(PRODUCTS);
  // Otherwise the module already auto-applies images to DOM elements on load.

  document.addEventListener('DOMContentLoaded', () => {
    // Wire product buttons
    attachProductGridListeners();

    // Re-apply images to DOM (safe, idempotent). Use force: true if you want to replace existing images.
    if (window.TypeImageUtils) {
      try {
        window.TypeImageUtils.applyTypeImagesToDOM({ width: 800, height: 560 });
      } catch (err) { console.warn('Failed to apply type images to DOM', err); }
    }
  });
})();